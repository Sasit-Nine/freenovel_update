<?php $__env->startSection('head'); ?>
<style>
    .fixed-size-image {
      width: 250px;
      height: 250px;
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    Read
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-2 my-5">
    <div class="card pt-4 pb-4 ps-4 pb-4 pe-4">
        <img src="<?php echo e($novel->img); ?>" class="rounded mx-auto d-block fixed-size-image mt-3 mb-3" alt="...">
        <h2><?php echo e($novel->title); ?></h2>
        <hr>
        <p><?php echo ($novel->content); ?></p>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nine/Documents/project/blog/web-blog/resources/views/read.blade.php ENDPATH**/ ?>