<?php $__env->startSection('title'); ?>
    About
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-2">
    <h1>เกี่ยวกับเรา</h1>
    <p>ผู้พัฒนาระบบ : <?php echo e($name); ?></p>
    <p>วันที่พัฒนา : <?php echo e($date); ?></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nine/Documents/project/blog/web-blog/resources/views/about.blade.php ENDPATH**/ ?>