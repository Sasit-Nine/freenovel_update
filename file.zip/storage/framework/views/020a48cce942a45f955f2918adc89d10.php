<?php $__env->startSection('title'); ?>
    All
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-2 my-5">
    <h1>นิยายทั้งหมด</h1>
    <hr>
    <div class="container cards-wrapper d-flex gx-5">
    <div class="row gy-3">
    <?php $__currentLoopData = $novel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
        <div class="card">
            <img src="<?php echo e($item->img); ?>" class="card-img-top" alt="...">
            <div class="card-body">
            <h5 class="card-title"><?php echo e($item->title); ?></h5>
            <p class="card-text">หมวดหมู่ : <?php echo e($item->category); ?></p>
            <a href="/blog/<?php echo e($item->id); ?>" class="btn btn-primary mt-3">อ่านเลย</a>
            </div>
        </div>  
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </div>  
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nine/Documents/project/blog/web-blog/resources/views/allnovel.blade.php ENDPATH**/ ?>