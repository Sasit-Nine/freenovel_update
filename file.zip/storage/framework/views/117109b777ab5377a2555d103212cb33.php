<?php $__env->startSection('title'); ?>
    All Novel
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(count($novel)>0): ?>
<div class="container py-2 mt-3 my-5">
    <h1>นิยายทั้งหมด</h1>
    <table class="table table-hover table-bordered text-center">
        <thead>
          <tr>
            <th scope="col">หน้าปก</th>
            <th scope="col">เรื่อง</th>
            <th scope="col">หมวดหมู่</th>
            <th scope="col">สถานะ</th>
            <th scope="col">เมนู</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $novel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="col-3"><img src="<?php echo e($item->img); ?>" class="rounded mx-auto d-block w-50" alt="..."></td>
                <th class="align-middle col-2" scope="row"><?php echo e($item->title); ?></th>
                
                <td class="align-middle col-1"><?php echo e($item->category); ?></td>
                <?php if($item->status==true): ?>
                    <td class="text text-success align-middle col-1">เผยแพร่แล้ว</td>
                <?php else: ?>
                    <td class="text text-danger align-middle col-1">ฉบับร่าง</td>
                <?php endif; ?>
                <td class="align-middle col-5">
                    <a href="<?php echo e(route('delete',$item->id)); ?>" class="btn btn-danger w-25"
                    onclick="return confirm('คุณต้องการลบนิยาย <?php echo e($item->title); ?> หรือไม่ ?')"    
                    >ลบ</a>
                    <a href="<?php echo e(route('edit',$item->id)); ?>" class="btn btn-warning w-25">แก้ไข</a>
                    <a href="<?php echo e(route('change',$item->id)); ?>" class="btn btn-success w-25">เปลี่ยนสถานะ</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
      <?php echo e($novel->links()); ?>

      <div class="text-center">
        <hr>
      </div>
</div>
<?php else: ?>
    <h1>ไม่มีนิยายในระบบ</h1>  
<?php endif; ?>


<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nine/Documents/project/blog/web-blog/resources/views/blog.blade.php ENDPATH**/ ?>